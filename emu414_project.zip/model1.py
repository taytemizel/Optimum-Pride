import gurobipy as gp
from gurobipy import GRB
import pandas as pd

# 1. Load Data from the 'data1' sheet of the Excel file
file_path = "input_data.xlsx"
df = pd.read_excel(file_path, sheet_name='data1')

# Clean column names to strip out any hidden trailing spaces
df.columns = df.columns.str.strip()
if 'i' in df.columns:
    df['i'] = df['i'].astype(str).str.strip()

# Set the index to 'i' (your category column) to convert rows to dictionaries
df.set_index('i', inplace=True)

# 2. Extract Parameters into Dictionaries
categories = df.index.tolist()

# Mapping to your exact excel column headers
C = df['c_i'].to_dict()
P_min = df['p_min'].to_dict()
P_max = df['p_max'].to_dict()
a = df['a_i'].to_dict()
b = df['b_i'].to_dict()

# 3. Initialize the Gurobi Model
m = gp.Model("Static_Pricing_Optimization")
m.setParam("LogFile", "gurobi1.log")  # Forces a dedicated log file

# 4. Decision Variables
P = m.addVars(categories, vtype=GRB.CONTINUOUS, name="Price")
D = m.addVars(categories, vtype=GRB.INTEGER, lb=0, name="Demand")

# 5. Constraints
# Constraint 1: Price Range Bounds
for i in categories:
    P[i].lb = P_min[i]
    P[i].ub = P_max[i]

# Constraint 2: Demand-Price Relationship
for i in categories:
    m.addConstr(D[i] <= a[i] - b[i] * P[i], name=f"Demand_Relationship_{i}")

# Constraint 3: Physical Capacity Limits
for i in categories:
    m.addConstr(D[i] <= C[i], name=f"Capacity_Limit_{i}")

# Constraint 4: Pricing Hierarchy (Premium rows must be more expensive)
for idx in range(len(categories) - 1):
    current_cat = categories[idx]
    next_cat = categories[idx + 1]
    m.addConstr(P[current_cat] >= P[next_cat], name=f"Hierarchy_{current_cat}_{next_cat}")

# 6. Objective Function: Maximize Total Revenue
m.setObjective(gp.quicksum(P[i] * D[i] for i in categories), GRB.MAXIMIZE)

# 7. Export Model to .lp File
m.write("model1.lp")
print("Optimization model successfully written to 'model.lp'.")

# 8. Optimize and Display Results
m.Params.NonConvex = 2
m.optimize()
m.write("model1.sol")

print("\n" + "="*70)
if m.status == GRB.OPTIMAL:
    print(f"STATIC MODEL OPTIMAL TOTAL REVENUE: {m.ObjVal:,.2f} TL\n")
    print(f"{'Category':<15} | {'Opt. Price (TL)':<15} | {'Tickets Sold':<15} | {'Revenue (TL)':<15} | {'Occupancy':<10}")
    print("-" * 70)
    for i in categories:
        price_val = P[i].X
        demand_val = D[i].X
        rev_val = price_val * demand_val
        occupancy_pct = (demand_val / C[i]) * 100
        print(f"{i:<15} | {price_val:<15.2f} | {demand_val:<15.0f} | {rev_val:<15.2f} | {occupancy_pct:<9.2f}%")
else:
    print("Optimization did not terminate with an optimal status.")
print("="*70 + "\n")
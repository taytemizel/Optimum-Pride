# Solution for model Static_Pricing_Optimization
# Objective value = 6041685.47830552
Price[1] 4170
Price[2] 3.2526315789473688e+03
Price[3] 2305.2
Price[4] 1.5297560975609756e+03
Demand[1] 111
Demand[2] 435
Demand[3] 572
Demand[4] 1860

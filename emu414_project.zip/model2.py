import gurobipy as gp
from gurobipy import GRB
import pandas as pd

# 1. Load Data from the 'data2' sheet of the Excel file
file_path = "input_data.xlsx"
df = pd.read_excel(file_path, sheet_name='data2')

# Clean column names to strip out any hidden trailing spaces
df.columns = df.columns.str.strip()

# 2. Extract Indices and Sets
# We use numeric categories [1, 2, 3, 4] and map them to their names for printing
categories = [1, 2, 3, 4]
periods = [1, 2, 3]

cat_names = {
    1: 'VIP',
    2: 'Front Rows',
    3: 'Middle Rows',
    4: 'Back Rows'
}

# The capacities (C_i) remain fixed as they define the physical venue size
C = {
    1: 111,
    2: 435,
    3: 572,
    4: 1860
}

# 3. Parse Parameters (p_min, p_max, a_it, b_it)
# We drop NaN values in these columns to just get the rows that contain period data
params_df = df[['i', 't', 'p_min', 'p_max', 'a_it', 'b_it']].dropna()
P_min = params_df.set_index(['i', 't'])['p_min'].to_dict()
P_max = params_df.set_index(['i', 't'])['p_max'].to_dict()
a = params_df.set_index(['i', 't'])['a_it'].to_dict()
b = params_df.set_index(['i', 't'])['b_it'].to_dict()

# 4. Parse Substitution Parameters (gamma)
# Initialize gamma to 0.0 for all (source, destination, period)
gamma = {(src, dst, t): 0.0 for src in categories for dst in categories for t in periods}

# The gamma parameters are stored in columns gamma_ij1, gamma_ij2, gamma_ij3
# where 'i' is the source category and 'j' is the destination category.
for _, row in df.iterrows():
    if pd.isna(row['i']) or pd.isna(row['j']):
        continue
    
    src = int(row['i'])
    dst = int(row['j'])
    
    if pd.notna(row['gamma_ij1']):
        gamma[(src, dst, 1)] = row['gamma_ij1']
    if pd.notna(row['gamma_ij2']):
        gamma[(src, dst, 2)] = row['gamma_ij2']
    if pd.notna(row['gamma_ij3']):
        gamma[(src, dst, 3)] = row['gamma_ij3']

# 5. Initialize the Gurobi Model
m = gp.Model("Dynamic_Pricing_Substitution")
m.setParam("LogFile", "gurobi2.log")  # Forces a dedicated log file
m.Params.NonConvex = 2

# 6. Decision Variables
P = m.addVars(categories, periods, vtype=GRB.CONTINUOUS, name="Price")
D = m.addVars(categories, periods, vtype=GRB.INTEGER, lb=0, name="Demand")

# 7. Constraints
# Constraint 1: Price Range Bounds
for i in categories:
    for t in periods:
        P[i, t].lb = P_min[i, t]
        P[i, t].ub = P_max[i, t]

# Constraint 2: Dynamic Demand with Substitution
# D_it <= a_it - b_it*P_it + SUM(gamma_ijt * P_jt)
for i in categories:
    for t in periods:
        # Sums the spillover demand incoming from all other source categories 'src'
        spillover = gp.quicksum(gamma[(src, i, t)] * P[src, t] for src in categories if src != i)
        m.addConstr(D[i, t] <= a[i, t] - b[i, t] * P[i, t] + spillover, name=f"Dynamic_Demand_{i}_t{t}")

# Constraint 3: Cumulative Capacity Limits across all time periods
for i in categories:
    m.addConstr(gp.quicksum(D[i, t] for t in periods) <= C[i], name=f"Total_Capacity_{i}")

# Constraint 4: Time-Monotonicity (Prices must only increase or stay the same over time)
for i in categories:
    for t in [1, 2]:
        m.addConstr(P[i, t] <= P[i, t+1], name=f"Monotonicity_{i}_t{t}")

# 8. Objective Function: Maximize Total Revenue
m.setObjective(gp.quicksum(P[i, t] * D[i, t] for i in categories for t in periods), GRB.MAXIMIZE)

# 9. Export Model to .lp File
# Save the model formulation specifically as 'model2.lp'
m.write("model2.lp")
print("Optimization model successfully written to 'model2.lp'.")

# 10. Optimize and Display Results
m.optimize()
m.write("model2.sol")

print("\n" + "="*80)
if m.status == GRB.OPTIMAL:
    print(f"DYNAMIC MODEL OPTIMAL TOTAL REVENUE: {m.ObjVal:,.2f} TL\n")
    print(f"{'Category':<15} | {'Period':<10} | {'Opt. Price (TL)':<15} | {'Tickets Sold':<15} | {'Revenue (TL)':<15}")
    print("-" * 80)
    
    for i in categories:
        cat_demand = 0
        cat_revenue = 0
        for t in periods:
            price_val = P[i, t].X
            demand_val = D[i, t].X
            revenue = price_val * demand_val
            
            cat_demand += demand_val
            cat_revenue += revenue
            
            period_name = "Early Bird" if t == 1 else "Regular" if t == 2 else "Last Call"
            cat_label = cat_names[i]
            print(f"{cat_label:<15} | {period_name:<10} | {price_val:<15.2f} | {demand_val:<15.0f} | {revenue:<15.2f}")
            
        print(f"  -> {cat_label} TOTALS: Sold {cat_demand:.0f}/{C[i]} | Section Revenue: {cat_revenue:,.2f} TL")
        print("-" * 80)
else:
    print("Optimization did not find an optimal solution.")
print("="*80 + "\n")
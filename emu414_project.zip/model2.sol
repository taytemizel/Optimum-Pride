# Solution for model Dynamic_Pricing_Substitution
# Objective value = 4.7326054343366595e+06
Price[1,1] 3540
Price[1,2] 4510
Price[1,3] 6300
Price[2,1] 2.5046147368421080e+03
Price[2,2] 3.2033070175438620e+03
Price[2,3] 4.0313684210526358e+03
Price[3,1] 1.8070298120982466e+03
Price[3,2] 2.4007713333333350e+03
Price[3,3] 3.0348400000000029e+03
Price[4,1] 9.9365853658536889e+02
Price[4,2] 1.3001052722864085e+03
Price[4,3] 1.8297031063414704e+03
Demand[1,1] 16
Demand[1,2] 27
Demand[1,3] 4
Demand[2,1] 120
Demand[2,2] 217
Demand[2,3] 57
Demand[3,1] 140
Demand[3,2] 236
Demand[3,3] 37
Demand[4,1] 551
Demand[4,2] 1078
Demand[4,3] 231
